package com.bookstore.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.bookstore.qa.base.TestBase;

public class LoginPage extends TestBase{
	
	@FindBy(id="userNameOrEmail")
	WebElement username;
	
	@FindBy(id="password")
	WebElement password;
	
	@FindBy(xpath="//button[contains(text(),'Sign In')]")
	WebElement signinbtn;
	
	@FindBy(xpath="//h1[contains(text(),'Latest Products')]")
	WebElement latestproducts;
	
	//Initializing the Page Objects:
			public LoginPage(){
				PageFactory.initElements(driver, this);
			}
			public void SignIn(String un, String pwd){
				username.sendKeys(un);
				password.sendKeys(pwd);
				//signinbtn.click();
			}
			public boolean validateBookstoreHeading(){
				return latestproducts.isDisplayed();
			}

}
