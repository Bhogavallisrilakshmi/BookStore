package com.bookstore.qa.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.bookstore.qa.base.TestBase;

public class Pagination extends TestBase{
	
	@FindBy(xpath="//ul[@class='pagination']//a[@class='page-link']")
    private List<WebElement> pages;
	
	@FindBy(xpath="//div[@class='card-title']//strong")
    private List<WebElement> books;
	
	public Pagination(){
		PageFactory.initElements(driver, this);
	}
	
	public String validatePagination() throws Exception {
		int s = pages.size();
		System.out.println("Total Number of Pages: "+ s);
		for (int i = 0; i < s; i++) {
		    pages.get(i).click();
		    Thread.sleep(1000);
		    System.out.println(i+1 + " Page is displayed and No.of books in "+(i+1)+" page is : " +books.size());
		}
		return driver.getTitle();
	}

}
