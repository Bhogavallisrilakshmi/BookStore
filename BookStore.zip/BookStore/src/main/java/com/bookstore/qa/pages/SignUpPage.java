package com.bookstore.qa.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.bookstore.qa.base.TestBase;

public class SignUpPage extends TestBase{
	
	@FindBy(xpath="//a[contains(text(),'Register')]")
	WebElement register;
	
	@FindBy(id="userName")
	WebElement username;
	
	@FindBy(id="firstName")
	WebElement firstname;
	
	@FindBy(id="email")
	WebElement email;
	
	@FindBy(xpath="//input[@placeholder='Password']")
	WebElement password;
	
	@FindBy(xpath="//input[@placeholder='Confirm Password']")
	WebElement confirmpassword;
	
	@FindBy(xpath="//button[contains(text(),'Register')]")
	WebElement registerbtn;
	
	@FindBy(xpath="//h1[contains(text(),'Latest Products')]")
	WebElement latestproducts;
	
	

	//Initializing the Page Objects:
		public SignUpPage(){
			PageFactory.initElements(driver, this);
		}
		
	//Actions:
		public void clickRegister(){
			register.click();
		}
		public String validateSignUpPageTitle(){
			return driver.getTitle();
		}
		public void fillSignUpForm() {
			username.sendKeys("tes");
			firstname.sendKeys("sri");
			email.sendKeys("testingbatchec22@gmail.com");
			password.sendKeys("123456");
			confirmpassword.sendKeys("123456");
			registerbtn.click();
			
		}
		
		public boolean validateBookstoreHeading(){
			return latestproducts.isDisplayed();
		}

}
