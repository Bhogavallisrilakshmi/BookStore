package com.bookstore.qa.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.bookstore.qa.base.TestBase;

public class VerifyPaymentReceipt extends TestBase{
	
	@FindBy(xpath="//div[@class='card-title']//strong")
    private List<WebElement> books;
	
	@FindBy(xpath="//button[contains(text(),'Add to Cart')]")
	WebElement addcart;
	
	@FindBy(xpath="//button[contains(text(),'Proceed To Checkout')]")
	WebElement checkout;
	
	@FindBy(name="billingAddress")
	WebElement billingaddress;
	
	@FindBy(xpath="//button[contains(text(),'Proceed to Payment')]")
	WebElement proceedpayment;
	
	@FindBy(name="paymentMethod")
	WebElement paymentmethod;
	
	@FindBy(xpath="//button[contains(text(),'Proceed to PlaceOrder')]")
	WebElement proceedToPlaceOrder;
	
	@FindBy(xpath="//button[contains(text(),'Place Order')]")
	WebElement placeorder;
		
	@FindBy(xpath="//strong[contains(text(),'Payment Receipt : ')]//following::a[1]")
	WebElement paymentreceipt;
	
	@FindBy(xpath="//td[contains(@class,'Title-copy')]")
	WebElement receipt;
	
	@FindBy(id="addressLine1")
	WebElement addressline1;
	
	@FindBy(id="addressLine2")
	WebElement addressline2;
	
	@FindBy(id="city")
	WebElement city;
	
	@FindBy(id="state")
	WebElement state;
	
	@FindBy(id="country")
	WebElement countrylist;
	
	@FindBy(id="postalCode")
	WebElement postalCode;
	
	@FindBy(id="phone")
	WebElement phone;
	
	@FindBy(xpath="//button[contains(text(),'Add New Address')]")
	WebElement addnewaddress;
	
	@FindBy(xpath="//button[contains(text(),'Add Card')]")
	WebElement addnewcard;
	
	
	public VerifyPaymentReceipt(){
		PageFactory.initElements(driver, this);
	}
	
	public void selectBook(String bookname) {
		System.out.println("Number of books: " +books.size());
		
		for (int i=0; i<books.size();i++){		    
		      String book = books.get(i).getText();
		      System.out.println("Name of the Book :" + books.get(i).getText());
		      if(book.equalsIgnoreCase(bookname)) {
		    	  books.get(i).click();
		      }
		    }
		
	}
	
	public void paymentProceed() throws Exception {
		Thread.sleep(1000);
		addcart.click();
		Thread.sleep(1000);
		checkout.click();
		Thread.sleep(1000);
		try {
			billingaddress.click();
		} catch (Exception e) {
			addNewAddress();
			billingaddress.click();
		}		
		Thread.sleep(1000);
		try {
			proceedpayment.click();
		} catch (Exception e) {
			addnewcard.click();
			proceedpayment.click();
		}
		
		Thread.sleep(1000);
		paymentmethod.click();
		Thread.sleep(1000);
		proceedToPlaceOrder.click();
		Thread.sleep(1000);
		placeorder.click();
		Thread.sleep(3000);
		paymentreceipt.click();
	}
	
	public void addNewAddress() {
		addressline1.sendKeys("Plot No:04");
		addressline2.sendKeys("Road No:05");
		city.sendKeys("Hyderabad");
		state.sendKeys("Telangana");
		Select country = new Select(countrylist);
		country.selectByVisibleText("India");
		postalCode.sendKeys("500049");
		phone.sendKeys("9876543210");
		addnewaddress.click();		
	}	
	
	public boolean verifyReceipt(){
		return receipt.isDisplayed();
	}

}
