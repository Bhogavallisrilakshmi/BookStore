package com.bookstore.qa.testcases;


import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.bookstore.qa.base.TestBase;
import com.bookstore.qa.pages.LoginPage;
import com.bookstore.qa.pages.Pagination;
import com.bookstore.qa.pages.VerifyPaymentReceipt;
import com.bookstore.qa.util.TestUtil;

public class PaginationTest extends TestBase{
	
	VerifyPaymentReceipt paymentReceipt;
	LoginPage loginPage;
	Pagination pagination;

		
	public PaginationTest(){
		super();
	}
	
	@BeforeMethod
	public void setUp(){
		initialization();
		loginPage = new LoginPage();
		pagination = new Pagination();
	}
	
		
	@Test(priority=1)
	public void homePagination() throws Exception{
		loginPage.SignIn(prop.getProperty("username"), prop.getProperty("password"));
		Thread.sleep(3000);
		//pagination.validatePagination();
		
		Assert.assertEquals(pagination.validatePagination(),"React App","Pagination is working fine");
	}
	
	@AfterMethod
	public void tearDown(){
		driver.quit();
	}

}
