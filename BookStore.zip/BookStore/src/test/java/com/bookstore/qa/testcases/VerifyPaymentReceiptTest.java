package com.bookstore.qa.testcases;


import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.bookstore.qa.base.TestBase;
import com.bookstore.qa.pages.LoginPage;
import com.bookstore.qa.pages.VerifyPaymentReceipt;
import com.bookstore.qa.util.TestUtil;

public class VerifyPaymentReceiptTest extends TestBase{
	
	VerifyPaymentReceipt paymentReceipt;
	LoginPage loginPage;
	TestUtil testUtil;
		
	public VerifyPaymentReceiptTest(){
		super();
	}
	
	@BeforeMethod
	public void setUp(){
		initialization();
		loginPage = new LoginPage();
		testUtil = new TestUtil();
		paymentReceipt = new VerifyPaymentReceipt();	
	}
	
		
	@Test(priority=1)
	public void paymentReceipt() throws Exception{
		loginPage.SignIn(prop.getProperty("username"), prop.getProperty("password"));
		Thread.sleep(3000);
		paymentReceipt.selectBook(prop.getProperty("bookname"));
		paymentReceipt.paymentProceed();
		testUtil.switchToWindow();
		Assert.assertTrue(paymentReceipt.verifyReceipt());
		
	}
	
	@AfterMethod
	public void tearDown(){
		driver.quit();
	}

}
