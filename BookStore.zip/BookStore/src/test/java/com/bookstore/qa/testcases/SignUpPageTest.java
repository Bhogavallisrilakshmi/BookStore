package com.bookstore.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.bookstore.qa.base.TestBase;
import com.bookstore.qa.pages.LoginPage;
import com.bookstore.qa.pages.SignUpPage;

public class SignUpPageTest extends TestBase{
	SignUpPage signupPage;
	
	public SignUpPageTest(){
		super();
	}
	
	@BeforeMethod
	public void setUp(){
		initialization();
		signupPage = new SignUpPage();	
	}
	
	@Test(priority=1)
	public void bookstoreSignUpTest() throws Exception{
		signupPage.clickRegister();
		String title = signupPage.validateSignUpPageTitle();
		Assert.assertEquals(title, "React App","SignUp page title not matched");
		signupPage.fillSignUpForm();
		Thread.sleep(2000);
		boolean flag = signupPage.validateBookstoreHeading();
		Assert.assertTrue(flag);
		
	}
	

	
	@AfterMethod
	public void tearDown(){
		driver.quit();
	}
	
	
	
	

}
